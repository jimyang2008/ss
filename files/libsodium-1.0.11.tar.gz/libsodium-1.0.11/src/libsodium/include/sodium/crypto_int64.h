#ifndef crypto_int64_H
#define crypto_int64_H

#include <stdint.h>

typedef int64_t crypto_int64;

#endif
